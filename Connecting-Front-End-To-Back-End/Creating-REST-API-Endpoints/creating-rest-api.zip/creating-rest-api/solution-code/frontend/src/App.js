import BookSchedule from './components/Booklist';


function App() {
  return (
    <div className="App">
    <h1>📚 BookNow 📚</h1>
     <BookSchedule />
    </div>
  );
}

export default App;
